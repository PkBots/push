//=Lu jual yatim lu no enc 085608542562
const chalk = require("chalk")
const fs = require("fs")

global.ownerNumber = ["6285608542562@s.whatsapp.net"]
global.nomerOwner = "6285608542562"
global.nomorOwner = ['6285608542562']
global.namaDeveloper = "Antares"
global.nameowner = "Antares"
global.namaBot = "Babycat-BOTS"
global.thumb = fs.readFileSync("./babycat/babycat.png")

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})

